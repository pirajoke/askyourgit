# Ask your GIT Prototype Install

1. Double-click `Ask your GIT Companion.app`.
   - If macOS blocks it, right-click -> Open, or use `install-companion.command`.
2. Open `chrome://extensions`.
3. Enable Developer mode.
4. Click "Load unpacked" and select this folder.
5. Restart Chrome.
6. Open any GitHub, GitLab, or Bitbucket repo and click "Ask your GIT".

The native host is the desktop companion. It lets the extension send install
commands to Terminal.app, iTerm2, or Warp.
