#!/bin/bash
set -e
cd "$(dirname "$0")"
bash native-host/install.sh
echo ""
echo "Ask your GIT Companion is installed."
echo "Next: chrome://extensions -> Load unpacked -> select this folder."
echo ""
read -r -p "Press Enter to close..."
